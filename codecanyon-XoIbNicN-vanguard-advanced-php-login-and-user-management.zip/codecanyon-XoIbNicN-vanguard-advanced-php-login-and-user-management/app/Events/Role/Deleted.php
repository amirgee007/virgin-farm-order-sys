<?php

namespace Vanguard\Events\Role;

class Deleted extends RoleEvent {}