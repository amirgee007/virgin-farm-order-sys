<?php

namespace Vanguard\Events\Permission;

class Deleted extends PermissionEvent {}